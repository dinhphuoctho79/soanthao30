# Biểu mẫu Word theo Nghị định 30/2020/NĐ-CP
Căn cứ: bản đọc kỹ toàn bộ Nghị định 30/2020/NĐ-CP (76 trang scan, file ~/workspace/nd30-doc-ky-toan-bo.md).
Khung chung mọi mẫu: khổ A4, lề trên/dưới 20 mm, lề trái 30 mm, lề phải 15 mm (nằm trong khoảng nghị định: trên/dưới 20-25, trái 30-35, phải 15-20), phông Times New Roman, màu đen, số trang từ 1, không hiện số trang thứ nhất.
## Cách điền mẫu
- Mọi chỗ trong [ngoặc vuông] là chỗ trống phải điền thật: tên tỉnh, tên xã, số, ngày, tên người, số tiền. Không có dữ liệu thật nào được điền sẵn.
- Số nhỏ hơn 10 thêm số 0 phía trước. Giữa số và ký hiệu có dấu /, giữa các nhóm chữ viết tắt có dấu - không cách chữ.
- Căn cứ viết nghiêng, mỗi căn cứ xuống dòng, cuối dòng dấu ;, dòng cuối dấu .
- Ký bằng mực xanh đối với văn bản giấy; dấu đỏ trùm khoảng 1/3 chữ ký về phía bên trái.
- Công văn không dùng chữ viết tắt tên loại; ký hiệu = tên cơ quan + tên đơn vị soạn thảo/lĩnh vực.
- Cấp xã theo mô hình 2 cấp: không đưa huyện vào. HĐND xã không ghi UBND tỉnh làm cơ quan chủ quản trực tiếp; để trống theo quy ước địa phương và xác nhận trước khi phát hành.
- Trạm Y tế: cơ quan chủ quản để dạng [Trung tâm Y tế … — xác nhận trước khi phát hành], không tự bịa tên. Người ký mặc định TRẠM TRƯỞNG, ký trực tiếp.
## Danh sách file
- cap-xa/: 22 file — Công văn, Công văn hỏa tốc, Công văn phúc đáp, Quyết định trực tiếp, Quyết định gián tiếp, Nghị quyết cá biệt, Thông báo, Thông báo kết luận họp, Tờ trình, Kế hoạch, Báo cáo, Giấy mời, Giấy giới thiệu, Biên bản, Giấy nghỉ phép, Công điện, Thông báo thôn/ấp, Phụ lục, Bản sao, Sổ đăng ký văn bản đi, Sổ đăng ký văn bản đến, Danh mục hồ sơ.
- tram-y-te-hiep-hung/: 14 file — Công văn, Công văn hỏa tốc, Thông báo, Tờ trình, Giấy mời, Quyết định, Kế hoạch, Báo cáo, Biên bản, Giấy giới thiệu, Phụ lục, Bản sao, Sổ đăng ký văn bản đi, Sổ đăng ký văn bản đến.
